FMF-AI 2027 | 3rd International Conference
Eger, Hungary | 28-30 January 2027

Files:
- fmfai2027-abstract-template.tex: short abstract template to fill in.
- fmfai2027.cls: class file (adapted from the original supplied 2026 class).
- references.bib: example references; replace with your own entries as needed.
- extended-example.tex: longer tutorial demonstrating the class commands.

All files belong in the same directory in your LaTeX editor / Overleaf project.
Select pdfLaTeX and Biber. You can compile with latexmk -pdf if available.
The class is for PDF abstract submission; it is not identical to the
Pandoc-based abstract HTML rendering used for the public conference website.

The extended example uses graphicx example-image assets; depending on the
installation, the mwe package may be needed for those example images.
The template shows sample authors, affiliations and a citation: replace them.
No official abstract length limit has been assumed.

Original class by Tibor Tomacs (2026); original author credit retained.
2027 date/headings update and concise example prepared for FMF-AI 2027.
